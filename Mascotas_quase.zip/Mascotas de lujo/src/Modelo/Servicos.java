package Modelo;
public class Servicos {
    private String nome;
    private String indicacao;
    private String preco;
    private String disponibilidade;
    private String desconto;
    private int id;
    public String getIndicacao() {
        return indicacao;
    }
    public void setIndicacao(String indicacao) {
        this.indicacao = indicacao;
    }
    public String getPreco() {
        return preco;
    }
    public void setPreco(String preco) {
        this.preco = preco;
    }
    public String getDisponibilidade() {
        return disponibilidade;
    }
    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
    public String getDesconto() {
        return desconto;
    }
    public void setDesconto(String desconto) {
        this.desconto = desconto;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}
