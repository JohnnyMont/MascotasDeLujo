package Controle;
import Modelo.Cliente;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlSecretaria {
    public boolean cadastrarCliente(Cliente cliente){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("INSERT INTO usuario(login,senha,tipoUsuario) VALUES(?,?,?);");
            ps.setString(1,cliente.getNome());
            ps.setString(2,cliente.getSenha());
            ps.setInt(3,cliente.getTipoUser());
            if(!ps.execute()){ 
                int idUser = 0;
                PreparedStatement ps3 = conectar.getCon().prepareStatement("SELECT id FROM usuario ORDER BY ID DESC LIMIT 1");
                ResultSet rs = ps3.executeQuery();
                if(rs != null){
                    while(rs.next()){
                        idUser = rs.getInt("id");
                    }
                }
                PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO clientes(nome,email,cpf,telefone,endereco,id_usuario) VALUES(?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
                ps2.setString(1,cliente.getNome());
                ps2.setString(2,cliente.getEmail());
                ps2.setString(3,cliente.getCpf());
                ps2.setString(4,cliente.getTelefone());
                ps2.setString(5,cliente.getEndereco());
                ps2.setInt(6,idUser);
                if(!ps2.execute()){ 
                    resultado = true;
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    public boolean alterarDadosClientes(String cpf, Cliente cliente){
        String cpf_oficial = cpf;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE clientes SET nome=?, email=?, endereco=?, telefone=? WHERE cpf=?");
            ps.setString(1,cliente.getNome());
            ps.setString(2,cliente.getEmail());
            ps.setString(3,cliente.getEndereco());
            ps.setString(4,cliente.getTelefone());
            ps.setString(5,cpf_oficial);
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public boolean excluirClientes(String cpf_oficial){
        try{
            Conexao conectar = new Conexao();
            int idUser = 0;
            PreparedStatement ps3 = conectar.getCon().prepareStatement("SELECT * FROM clientes WHERE cpf=? LIMIT 1");
            ps3.setString(1,cpf_oficial);
            ResultSet rs = ps3.executeQuery();
            if(rs != null){
                while(rs.next()){
                    idUser = rs.getInt("id_usuario");
                }
            }   
            PreparedStatement ps = conectar.getCon().prepareStatement("DELETE FROM animais WHERE cpfCliente=?");
            ps.setString(1,cpf_oficial);
            if(!ps.execute()){
                PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM clientes WHERE cpf=?");
                ps2.setString(1,cpf_oficial);
                if(!ps2.execute()){
                    PreparedStatement ps4 = conectar.getCon().prepareStatement("DELETE FROM usuario WHERE id=?");
                    ps4.setInt(1,idUser);
                    ps4.execute();
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public ArrayList visualizarClientes(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM clientes;");
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){ 
                    Cliente li = new Cliente("","");
                    li.setCpf(rs.getString("cpf"));  
                    li.setNome(rs.getString("nome"));
                    li.setEmail(rs.getString("email"));
                    li.setTelefone(rs.getString("telefone"));
                    li.setEndereco(rs.getString("endereco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
        }
        return lista;
    }
    public boolean cadastrarAnimais(Animais animal){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO animais(nome,tipo,raca,tamanho,peso,idade,cpfCliente) VALUES(?,?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
            ps2.setString(1,animal.getNome());
            ps2.setString(2,animal.getTipo());
            ps2.setString(3,animal.getRaca());
            ps2.setString(4,animal.getTamanho());
            ps2.setString(5,animal.getPeso());
            ps2.setInt(6,animal.getIdade());
            ps2.setString(7,animal.getCpf_cliente());
            if(!ps2.execute()){ 
                resultado = true;
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    public boolean alterarDadosAnimais(int id, Animais animal){
        int id_oficial = id;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE animais SET nome=?, tipo=?, raca=?, tamanho=?,peso=?,idade=?,cpfCliente=? WHERE id=?");
            ps.setString(1,animal.getNome());
            ps.setString(2,animal.getTipo());
            ps.setString(3,animal.getRaca());
            ps.setString(4,animal.getTamanho());
            ps.setString(5,animal.getPeso());
            ps.setInt(6,animal.getIdade());
            ps.setString(7,animal.getCpf_cliente());
            ps.setInt(8,id_oficial);
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public boolean excluirAnimais(int id){
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM animais WHERE id=?");
            ps2.setInt(1,id);
            ps2.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public ArrayList visualizarAnimais(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM animais");
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){
                    Animais li = new Animais();
                    li.setId(rs.getInt("id"));
                    li.setNome(rs.getString("nome"));
                    li.setTipo(rs.getString("tipo"));
                    li.setTamanho(rs.getString("tamanho"));
                    li.setRaca(rs.getString("raca"));
                    li.setPeso(rs.getString("peso"));
                    li.setIdade(rs.getInt("idade"));
                    li.setCpf_cliente(rs.getString("cpfCliente"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList consultarServicos(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos");
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){ 
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList consultarCompras(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM compra");
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){ 
                    Compra li = new Compra();
                    li.setId(rs.getInt("id"));
                    li.setCpfCliente(rs.getString("cpfCliente"));
                    li.setCodAnimal(rs.getInt("codAnimal"));
                    li.setFormaPagamento(rs.getString("formaPagamento"));
                    li.setTotal(rs.getString("total"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public boolean fecharCompra(String cpf_cliente,String nome_animal, String servico,String formaPagamento){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
            String desconto2;
            String valor2;
            int id_servico = 0;
            int id_animal = 0;
            double valor = 0.0;
            double desconto = 0.0;
            double preco = 0.0;
            PreparedStatement ps1 = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE nome = ?");
            ps1.setString(1,servico);
            ResultSet rs = ps1.executeQuery();
            if(rs != null){
                while(rs.next()){
                    id_servico = rs.getInt("id");
                    desconto2 = rs.getString("desconto");
                    valor2 = rs.getString("preco");
                    valor = Double.parseDouble(valor2);
                    desconto = Double.parseDouble(desconto2);
                    preco = valor-desconto;
                }
            }
            System.out.println(valor);
            System.out.println(id_servico);
            System.out.println(desconto);
            PreparedStatement ps2 = conectar.getCon().prepareStatement("SELECT id,nome FROM animais WHERE nome = ?");
            ps2.setString(1,nome_animal);
            ResultSet rs2 = ps2.executeQuery();
            if(rs2 != null){
                while(rs2.next()){
                    id_animal = rs2.getInt("id");
                }
                PreparedStatement ps3 = conectar.getCon().prepareStatement("INSERT INTO compra(cpfCliente,codAnimal,total,formaPagamento,id_servico) VALUES(?,?,?,?,?);");
                ps3.setString(1,cpf_cliente);
                ps3.setInt(2,id_animal);
                ps3.setString(3,Double.toString(preco));
                ps3.setString(4,formaPagamento);
                ps3.setInt(5,id_servico);
                if(!ps3.execute()){ 
                    resultado = true;
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return resultado;
    }
}