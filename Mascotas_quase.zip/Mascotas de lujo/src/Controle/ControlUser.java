package Controle;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class ControlUser {
    public int consultarTipo(String loginU, String senhaU){
        int tipoUser = 3;
        try{
            Conexao conectar = new Conexao(); 
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM usuario WHERE login = ? && senha = ?;"); 
            ps.setString(2,senhaU);
            ps.setString(1,loginU);
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){ 
                    tipoUser = rs.getInt("tipoUsuario");
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return tipoUser;
    }
}