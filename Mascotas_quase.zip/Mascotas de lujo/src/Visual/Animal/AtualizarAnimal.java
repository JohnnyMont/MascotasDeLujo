package Visual.Animal;
import Controle.Conexao;
import Controle.ControlSecretaria;
import Modelo.Animais;
import Visual.PrincipalSecretaria;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class AtualizarAnimal extends javax.swing.JFrame {
    private void atualizaTabela(){
        ControlSecretaria controle = new ControlSecretaria();
        ArrayList<Animais> lista = controle.visualizarAnimais();
        DefaultTableModel tbm = (DefaultTableModel) tbAnimais.getModel();
        while(tbm.getRowCount() > 0){
            tbm.removeRow(0);
        }
        try{
            if(lista != null){
                int i = 0;
                for(Animais liv : lista){
                    tbm.addRow(new String[i]);
                    tbAnimais.setValueAt(liv.getId(), i, 0);
                    tbAnimais.setValueAt(liv.getNome(), i, 1);
                    tbAnimais.setValueAt(liv.getTipo(), i, 2);
                    tbAnimais.setValueAt(liv.getTamanho(), i, 3);
                    tbAnimais.setValueAt(liv.getRaca(), i, 4);
                    tbAnimais.setValueAt(liv.getPeso(), i, 5);
                    tbAnimais.setValueAt(liv.getIdade(), i, 6);
                    tbAnimais.setValueAt(liv.getCpf_cliente(), i, 7);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    }
    public AtualizarAnimal() {
        initComponents();
        atualizaTabela();
        ButtonGroup buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup1.add(pequeno);
        buttonGroup1.add(medio);
        buttonGroup1.add(grande);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cadastrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbAnimais = new javax.swing.JTable();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel6 = new javax.swing.JLabel();
        cpf_cliente = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter cpfC= new javax.swing.text.MaskFormatter("###.###.###-##");
            cpf_cliente = new javax.swing.JFormattedTextField(cpfC);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Digite o campo CPF correto!!", "Programinha",JOptionPane.ERROR_MESSAGE);
        }
        jLabel8 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        grande = new javax.swing.JRadioButton();
        medio = new javax.swing.JRadioButton();
        pequeno = new javax.swing.JRadioButton();
        especie = new javax.swing.JComboBox<>();
        raca = new javax.swing.JComboBox<>();
        kilos = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();
        gramas = new javax.swing.JSpinner();
        jLabel12 = new javax.swing.JLabel();
        idade = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("Id:");

        cadastrar.setBackground(java.awt.Color.blue);
        cadastrar.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        cadastrar.setForeground(new java.awt.Color(255, 255, 255));
        cadastrar.setText("Atualizar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel2.setText("Tamanho:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel3.setText("Nome:");

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel7.setText("Atualizar Informaçoes do Animal");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel4.setText("Raça:");

        id.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel5.setText("Peso:");

        tbAnimais.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nome", "Tipo", "Tamanho", "Raça", "Peso", "Idade", "CPF do Cliente"
            }
        ));
        jScrollPane2.setViewportView(tbAnimais);

        jToggleButton1.setBackground(java.awt.Color.blue);
        jToggleButton1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jToggleButton1.setForeground(new java.awt.Color(255, 255, 255));
        jToggleButton1.setText("Voltar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel6.setText("Idade:");

        cpf_cliente.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        cpf_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cpf_clienteActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel8.setText("Cpf do Cliente:");

        nome.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        nome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nomeMouseClicked(evt);
            }
        });
        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel10.setText("Espécie:");

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats.png"))); // NOI18N

        grande.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        grande.setText("Grande");

        medio.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        medio.setText("Médio");
        medio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medioActionPerformed(evt);
            }
        });

        pequeno.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        pequeno.setText("Pequeno");
        pequeno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pequenoActionPerformed(evt);
            }
        });

        especie.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        raca.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        raca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                racaMouseClicked(evt);
            }
        });

        kilos.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel9.setText("Kg");

        gramas.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel12.setText("g");

        idade.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(630, 630, 630)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cpf_cliente))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(kilos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gramas, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel12)
                                .addGap(25, 25, 25)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(idade))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(id)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(especie, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(27, 27, 27)
                                .addComponent(pequeno)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addComponent(medio)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(grande))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(raca, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 4, Short.MAX_VALUE)
                        .addComponent(cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 825, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(505, 505, 505))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addGap(18, 18, 18)
                        .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(380, 380, 380))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(especie)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(raca))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(pequeno)
                        .addComponent(medio)
                        .addComponent(grande)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(kilos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(gramas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(jLabel6)
                        .addComponent(idade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(cpf_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cadastrar)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(87, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jToggleButton1)
                        .addGap(34, 34, 34))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
        PrincipalSecretaria visualizar = new PrincipalSecretaria();
        Animais animal = new Animais();
        animal.setNome(nome.getText());
        animal.setTipo(especie.getSelectedItem().toString());
        if(grande.isSelected()){
            animal.setTamanho("Grande");
        }else if(medio.isSelected()){
            animal.setTamanho("Médio");
        }else if(pequeno.isSelected()){
            animal.setTamanho("Pequeno");
        }
        animal.setRaca(raca.getSelectedItem().toString());
        animal.setPeso(kilos.getValue().toString()+","+gramas.getValue().toString());
        animal.setIdade(Integer.parseInt(idade.getValue().toString()));
        animal.setCpf_cliente(cpf_cliente.getText());
        ControlSecretaria controle = new ControlSecretaria();
        if(controle.alterarDadosAnimais(Integer.parseInt(id.getText()),animal)){
            JOptionPane.showMessageDialog(null,"Edição efetuada com Sucesso");
            dispose();
        }
    }//GEN-LAST:event_cadastrarActionPerformed
    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed
    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jToggleButton1ActionPerformed
    private void cpf_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cpf_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cpf_clienteActionPerformed
    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeActionPerformed

    private void medioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_medioActionPerformed

    private void pequenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pequenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pequenoActionPerformed

    private void racaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_racaMouseClicked
        int itemAnimal = raca.getItemCount();
        for(int i=0;i<itemAnimal;i++){
            raca.removeItemAt(0);
        }
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("SELECT nome FROM raca WHERE especie = ?");
            ps2.setString(1,especie.getSelectedItem().toString());
            ResultSet rs2 = ps2.executeQuery();
            if(rs2 != null){
                while(rs2.next()){
                    raca.addItem(rs2.getString("nome"));
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_racaMouseClicked

    private void nomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nomeMouseClicked
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("SELECT * FROM animais WHERE id = ?");
            ps2.setInt(1,Integer.parseInt(id.getText()));
            ResultSet rs2 = ps2.executeQuery();
            String array[] = new String[2];
            String peso = "";
            if(rs2 != null){
                while(rs2.next()){
                    nome.setText(rs2.getString("nome"));
                    cpf_cliente.setText(rs2.getString("cpfCliente"));
                    idade.setValue(rs2.getInt("idade"));
                    peso = rs2.getString("peso");
                    array = peso.split(",");
                    kilos.setValue(Integer.parseInt(array[0]));
                    gramas.setValue(Integer.parseInt(array[1]));
                    nome.setText(rs2.getString("nome"));
                    switch (rs2.getString("tamanho")) {
                        case "Pequeno":
                            pequeno.setSelected(true);
                            break;
                        case "Médio":
                            medio.setSelected(true);
                            break;
                        case "Grande":
                            grande.setSelected(true);
                            break;
                        default:
                            break;
                    }
                    especie.addItem(rs2.getString("tipo"));
                    raca.addItem(rs2.getString("raca"));
                    try{
            PreparedStatement ps3 = conectar.getCon().prepareStatement("SELECT nome FROM especie");
            ResultSet rs = ps3.executeQuery();
            if(rs != null){
                while(rs.next()){
                    especie.addItem(rs.getString("nome"));
                }
            }
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT nome FROM raca WHERE especie = ?");
            ps2.setString(1,especie.getSelectedItem().toString());
            ResultSet rs3 = ps.executeQuery();
            if(rs3 != null){
                while(rs3.next()){
                    raca.addItem(rs3.getString("nome"));
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_nomeMouseClicked
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable(){
            public void run(){
                new AtualizarAnimal().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrar;
    private javax.swing.JTextField cpf_cliente;
    private javax.swing.JComboBox<String> especie;
    private javax.swing.JSpinner gramas;
    private javax.swing.JRadioButton grande;
    private javax.swing.JTextField id;
    private javax.swing.JSpinner idade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JSpinner kilos;
    private javax.swing.JRadioButton medio;
    private javax.swing.JTextField nome;
    private javax.swing.JRadioButton pequeno;
    private javax.swing.JComboBox<String> raca;
    private javax.swing.JTable tbAnimais;
    // End of variables declaration//GEN-END:variables
}
