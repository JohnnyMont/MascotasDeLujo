package Visual;
import Visual.Animal.*;
import Visual.Servico.ConsulServico;
import Visual.cliente.CadastroCliente;
import Visual.cliente.AtualizarCliente;
import Visual.cliente.VisualizarClientes;
import Visual.cliente.ExcluirCliente;
public class PrincipalSecretaria extends javax.swing.JFrame {
    public PrincipalSecretaria() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel9 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        cadastrarcliente = new javax.swing.JMenuItem();
        alterarcliente = new javax.swing.JMenuItem();
        visualizarclientes = new javax.swing.JMenuItem();
        excluirclientes = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        cadanimal = new javax.swing.JMenuItem();
        cadanimal1 = new javax.swing.JMenuItem();
        cadanimal2 = new javax.swing.JMenuItem();
        cadanimal3 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        consulservico = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel1.setText("Bem-Vinda Secretária!");

        jToggleButton1.setBackground(java.awt.Color.blue);
        jToggleButton1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jToggleButton1.setForeground(java.awt.Color.white);
        jToggleButton1.setText("Sair");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats.png"))); // NOI18N

        jMenuBar1.setBackground(java.awt.Color.blue);
        jMenuBar1.setForeground(java.awt.Color.white);

        jMenu2.setBackground(java.awt.Color.blue);
        jMenu2.setForeground(java.awt.Color.white);
        jMenu2.setText("Cliente");

        cadastrarcliente.setBackground(java.awt.Color.blue);
        cadastrarcliente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cadastrarcliente.setForeground(java.awt.Color.white);
        cadastrarcliente.setText("Cadastrar");
        cadastrarcliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarclienteActionPerformed(evt);
            }
        });
        jMenu2.add(cadastrarcliente);

        alterarcliente.setBackground(java.awt.Color.blue);
        alterarcliente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        alterarcliente.setForeground(new java.awt.Color(255, 255, 255));
        alterarcliente.setText("Alterar Dados");
        alterarcliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alterarclienteActionPerformed(evt);
            }
        });
        jMenu2.add(alterarcliente);

        visualizarclientes.setBackground(java.awt.Color.blue);
        visualizarclientes.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        visualizarclientes.setForeground(new java.awt.Color(255, 255, 255));
        visualizarclientes.setText("Visualizar Todos");
        visualizarclientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                visualizarclientesActionPerformed(evt);
            }
        });
        jMenu2.add(visualizarclientes);

        excluirclientes.setBackground(java.awt.Color.blue);
        excluirclientes.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        excluirclientes.setForeground(new java.awt.Color(255, 255, 255));
        excluirclientes.setText("Excluir");
        excluirclientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                excluirclientesActionPerformed(evt);
            }
        });
        jMenu2.add(excluirclientes);

        jMenuBar1.add(jMenu2);

        jMenu3.setForeground(java.awt.Color.white);
        jMenu3.setText("Animal");

        cadanimal.setBackground(new java.awt.Color(0, 51, 255));
        cadanimal.setForeground(new java.awt.Color(255, 255, 255));
        cadanimal.setText("Cadastrar");
        cadanimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadanimalActionPerformed(evt);
            }
        });
        jMenu3.add(cadanimal);

        cadanimal1.setBackground(new java.awt.Color(0, 0, 240));
        cadanimal1.setForeground(new java.awt.Color(255, 255, 255));
        cadanimal1.setText("Atualizar");
        cadanimal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadanimal1ActionPerformed(evt);
            }
        });
        jMenu3.add(cadanimal1);

        cadanimal2.setBackground(new java.awt.Color(0, 0, 240));
        cadanimal2.setForeground(new java.awt.Color(255, 255, 255));
        cadanimal2.setText("Visualizar");
        cadanimal2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadanimal2ActionPerformed(evt);
            }
        });
        jMenu3.add(cadanimal2);

        cadanimal3.setBackground(new java.awt.Color(0, 0, 240));
        cadanimal3.setForeground(new java.awt.Color(255, 255, 255));
        cadanimal3.setText("Excluir");
        cadanimal3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadanimal3ActionPerformed(evt);
            }
        });
        jMenu3.add(cadanimal3);

        jMenuBar1.add(jMenu3);

        jMenu4.setForeground(java.awt.Color.white);
        jMenu4.setText("Serviço ");

        consulservico.setBackground(new java.awt.Color(0, 0, 240));
        consulservico.setForeground(new java.awt.Color(255, 255, 255));
        consulservico.setText("Consultar");
        consulservico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consulservicoActionPerformed(evt);
            }
        });
        jMenu4.add(consulservico);

        jMenuBar1.add(jMenu4);

        jMenu5.setForeground(java.awt.Color.white);
        jMenu5.setText("Compra");

        jMenuItem8.setBackground(new java.awt.Color(0, 0, 240));
        jMenuItem8.setForeground(new java.awt.Color(255, 255, 255));
        jMenuItem8.setText("Finalizar");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem8);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(654, 654, 654))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jToggleButton1)
                            .addComponent(jLabel9))
                        .addGap(34, 34, 34))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addGap(233, 233, 233)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 267, Short.MAX_VALUE)
                .addComponent(jToggleButton1)
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void excluirclientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excluirclientesActionPerformed
        ExcluirCliente excluir = new ExcluirCliente();
        excluir.setVisible(true);
    }//GEN-LAST:event_excluirclientesActionPerformed
    private void cadastrarclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarclienteActionPerformed
        CadastroCliente cadastro = new CadastroCliente();
        cadastro.setVisible(true);
    }//GEN-LAST:event_cadastrarclienteActionPerformed
    private void visualizarclientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_visualizarclientesActionPerformed
        VisualizarClientes visualizar = new VisualizarClientes();
        visualizar.setVisible(true);
    }//GEN-LAST:event_visualizarclientesActionPerformed
    private void alterarclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alterarclienteActionPerformed
        AtualizarCliente alterar = new AtualizarCliente();
        alterar.setVisible(true);
    }//GEN-LAST:event_alterarclienteActionPerformed
    private void consulservicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consulservicoActionPerformed
        ConsulServico consultar = new ConsulServico();
        consultar.setVisible(true);
    }//GEN-LAST:event_consulservicoActionPerformed
    private void cadanimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadanimalActionPerformed
        CadastroAnimal cadastroanimal = new CadastroAnimal();
        cadastroanimal.setVisible(true);
    }//GEN-LAST:event_cadanimalActionPerformed
    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        CadastrarCompras compra = new CadastrarCompras();
        compra.setVisible(true);
    }//GEN-LAST:event_jMenuItem8ActionPerformed
    private void cadanimal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadanimal1ActionPerformed
        AtualizarAnimal animal = new AtualizarAnimal();
        animal.setVisible(true);
    }//GEN-LAST:event_cadanimal1ActionPerformed
    private void cadanimal2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadanimal2ActionPerformed
        VisualizarAnimais animal = new VisualizarAnimais();
        animal.setVisible(true);
    }//GEN-LAST:event_cadanimal2ActionPerformed
    private void cadanimal3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadanimal3ActionPerformed
        ExcluirAnimal animal = new ExcluirAnimal();
        animal.setVisible(true);
    }//GEN-LAST:event_cadanimal3ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        Logar logar = new Logar();
        logar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jToggleButton1ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalSecretaria().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem alterarcliente;
    private javax.swing.JMenuItem cadanimal;
    private javax.swing.JMenuItem cadanimal1;
    private javax.swing.JMenuItem cadanimal2;
    private javax.swing.JMenuItem cadanimal3;
    private javax.swing.JMenuItem cadastrarcliente;
    private javax.swing.JMenuItem consulservico;
    private javax.swing.JMenuItem excluirclientes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JMenuItem visualizarclientes;
    // End of variables declaration//GEN-END:variables
}
