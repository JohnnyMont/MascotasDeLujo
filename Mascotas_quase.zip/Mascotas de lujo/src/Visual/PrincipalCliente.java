package Visual;

import Visual.Servico.ConsulServico;

public class PrincipalCliente extends javax.swing.JFrame {
    public PrincipalCliente() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        sair = new javax.swing.JToggleButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        compranome = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        promocoes = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel1.setText("Bem-Vindo Cliente!");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats.png"))); // NOI18N

        sair.setBackground(java.awt.Color.blue);
        sair.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        sair.setForeground(java.awt.Color.white);
        sair.setText("Sair");
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });

        jMenuBar1.setBackground(new java.awt.Color(0, 0, 240));
        jMenuBar1.setForeground(new java.awt.Color(255, 255, 255));

        compranome.setForeground(new java.awt.Color(255, 255, 255));
        compranome.setText("Consultar");

        jMenuItem1.setBackground(new java.awt.Color(0, 0, 240));
        jMenuItem1.setForeground(new java.awt.Color(255, 255, 255));
        jMenuItem1.setText("Serviços");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        compranome.add(jMenuItem1);

        promocoes.setBackground(new java.awt.Color(0, 0, 240));
        promocoes.setForeground(new java.awt.Color(255, 255, 255));
        promocoes.setText("Promoções");
        promocoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                promocoesActionPerformed(evt);
            }
        });
        compranome.add(promocoes);

        jMenuBar1.add(compranome);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sair)
                    .addComponent(jLabel9))
                .addGap(34, 34, 34))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(723, 723, 723)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 361, Short.MAX_VALUE)
                .addComponent(sair)
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void promocoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_promocoesActionPerformed
        ConsulPromocoes promo = new ConsulPromocoes();
        promo.setVisible(true);
    }//GEN-LAST:event_promocoesActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ConsulServico promo = new ConsulServico();
        promo.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
        Logar logar = new Logar();
        logar.setVisible(true);
        dispose();
    }//GEN-LAST:event_sairActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalCliente().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu compranome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem promocoes;
    private javax.swing.JToggleButton sair;
    // End of variables declaration//GEN-END:variables
}
