﻿CREATE SCHEMA IF NOT EXISTS MascotasDeLujo;
CREATE TABLE IF NOT EXISTS MascotasDeLujo.usuario(
	id INT(3) PRIMARY KEY AUTO_INCREMENT,
	login VARCHAR(255) NOT NULL,
	senha VARCHAR(255) NOT NULL,
	tipoUsuario INT(1) NOT NULL
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.administrador(
	id INT (3) PRIMARY KEY AUTO_INCREMENT,
	senhaExtra VARCHAR(255) NOT NULL,
	id_usuario INT(3),
	FOREIGN KEY (id_usuario) REFERENCES  MascotasDeLujo.usuario(id)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.clientes(
	nome VARCHAR(255) NOT NULL,
	email VARCHAR(255) NOT NULL,
	cpf VARCHAR(15) PRIMARY KEY,
	telefone VARCHAR(14) NOT NULL,
	endereco VARCHAR(255) NOT NULL,
	id_usuario INT(3),
	FOREIGN KEY (id_usuario) REFERENCES  MascotasDeLujo.usuario(id)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.secretaria(
	id INT (3) PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(255) NOT NULL,
	endereco VARCHAR(255) NOT NULL,
	cpf VARCHAR(15) NOT NULL,
	rg VARCHAR(12) NOT NULL,
	telefone VARCHAR(14) NOT NULL,
	id_usuario INT(3),
	FOREIGN KEY (id_usuario) REFERENCES  MascotasDeLujo.usuario(id)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.especie(
	nome VARCHAR(255) PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.raca(
	nome VARCHAR(255) PRIMARY KEY,
	especie VARCHAR(255),
	FOREIGN KEY (especie) REFERENCES MascotasDeLujo.especie(nome)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.animais(
	id INT(3) PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(255) NOT NULL,
	tipo VARCHAR(255) NOT NULL,
	raca VARCHAR(255) NOT NULL,
	tamanho VARCHAR(255) NOT NULL,
	peso VARCHAR(255) NOT NULL,
	idade INT(3) NOT NULL,
	cpfCliente VARCHAR(15),
	FOREIGN KEY (cpfCliente) REFERENCES MascotasDeLujo.clientes(cpf),
	FOREIGN KEY (tipo) REFERENCES MascotasDeLujo.especie(nome),
	FOREIGN KEY (raca)REFERENCES MascotasDeLujo.raca(nome)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.servicos(
	id INT(3) PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(255) NOT NULL,
	preco VARCHAR(255) NOT NULL,
	disponibilidade VARCHAR(255) NOT NULL,
	desconto VARCHAR(255) NOT NULL,
	indicacao VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS MascotasDeLujo.compra(
	id INT (3) PRIMARY KEY AUTO_INCREMENT,
	cpfCliente VARCHAR(15) NOT NULL,
	codAnimal INT(3),
	total VARCHAR(255) NOT NULL,
	formaPagamento VARCHAR(255) NOT NULL,
	FOREIGN KEY (cpfCliente) REFERENCES  MascotasDeLujo.clientes(cpf),
	id_servico INT(3),
	FOREIGN KEY (id_servico) REFERENCES  MascotasDeLujo.servicos(id),
	FOREIGN KEY (codAnimal) REFERENCES  MascotasDeLujo.animais(id)
);	
INSERT INTO MascotasDeLujo.usuario(login,senha,tipoUsuario) VALUES("Admin","admin",0);
INSERT INTO MascotasDeLujo.administrador(senhaExtra,id_usuario) VALUES("admin123",1);
INSERT INTO MascotasDeLujo.usuario(login,senha,tipoUsuario) VALUES("Maria","secretaria",2);
INSERT INTO MascotasDeLujo.secretaria(nome,endereco,cpf,rg,telefone,id_usuario) VALUES("Maria","Rua Alta Nº123","000.000.000.00","0000000000-0","(85)90000-0000",2);
