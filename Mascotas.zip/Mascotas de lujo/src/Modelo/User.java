package Modelo;
public class User {
    private String login;
    private String senha;
    private int tipoUser;
   
    public User(int tipo, String log, String sen){
        tipoUser = tipo;
        login = log;
        senha = sen;
    }
    public String getLogin() {
        return login;
    }  
    public void setLogin(String login) {
        this.login = login;
    } 
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public int getTipoUser() {
        return tipoUser;
    }
    public void setTipoUser(int tipoUser) {
        this.tipoUser = tipoUser;
    }
}
