package Modelo;
public class Compra {
    private String cpfCliente;
    private int codAnimal;
    private Servicos listarServicos;
    private double desconto;
    private double total;
    private String formaPagamento;
    public String getCpfCliente() {
        return cpfCliente;
    }
    public void setCpfCliente(String cpfCliente) {
        this.cpfCliente = cpfCliente;
    }
    public int getCodAnimal() {
        return codAnimal;
    }
    public void setCodAnimal(int codAnimal) {
        this.codAnimal = codAnimal;
    }
    public Servicos getListarServicos() {
        return listarServicos;
    }
    public void setListarServicos(Servicos listarServicos) {
        this.listarServicos = listarServicos;
    }
    public double getDesconto() {
        return desconto;
    }
    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }
    public double getTotal() {
        return total;
    }
    public void setTotal(double total) {
        this.total = total;
    }
    public String getFormaPagamento() {
        return formaPagamento;
    }
    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }  
    public Compra(){
         this.listarServicos = new Servicos();
    }
}
