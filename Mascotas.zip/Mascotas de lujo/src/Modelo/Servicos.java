package Modelo;
public class Servicos {
    private Animais indicacao;
    private float preco;
    private String disponibilidade;
    private float desconto;
    public Animais getIndicacao() {
        return indicacao;
    }
    public void setIndicacao(Animais indicacao) {
        this.indicacao = indicacao;
    }
    public float getPreco() {
        return preco;
    }
    public void setPreco(float preco) {
        this.preco = preco;
    }
    public String getDisponibilidade() {
        return disponibilidade;
    }
    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
    public float getDesconto() {
        return desconto;
    }
    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }
}
