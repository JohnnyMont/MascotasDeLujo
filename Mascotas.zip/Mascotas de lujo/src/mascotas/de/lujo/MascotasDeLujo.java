/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mascotas.de.lujo;

import Visual.Inicial;


/**
 *
 * @author aluno
 */
public class MascotasDeLujo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     Inicial inicial = new Inicial();
     inicial.setVisible(true);
    }

   
}
