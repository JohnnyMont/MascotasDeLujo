package Controle;
import Modelo.Cliente;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
import jdk.nashorn.internal.codegen.CompilerConstants;
public class ControlClientes {
    private Cliente cliente;
    public static void comprarServicoTipoAnimal(){
        //Compra de serviço por tipo de animal
    }
    public static void compraServicoNome(){
        //Compra de serviço pelo nome
    }
    public static void listarPromocoes(){
        //listar Promoções
    }
}