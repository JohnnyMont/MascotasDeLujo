package Controle;
import Modelo.Cliente;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
import static java.lang.Integer.parseInt;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlClientes {
    private Cliente cliente;
    public static void comprarServicoTipoAnimal(){
        //Compra de serviço por tipo de animal
    }
    public static void compraServicoNome(){
        //Compra de serviço pelo nome
    }
    public static void listarPromocoes(){
        //listar Promoções
    }
    public boolean cadCliente(Cliente cliente){
        boolean resultado = false;
         try{
		Conexao conectar = new Conexao();
		PreparedStatement ps = conectar.getCon().prepareStatement("INSERT INTO usuario(login,senha,tipoUsuario) VALUES(?,?,?);");
                ps.setString(1,cliente.getNome());
		ps.setString(2,cliente.getSenha());
		ps.setInt(3,cliente.getTipoUser());
                if(!ps.execute()){ 
                    int idUser = 0;
                    PreparedStatement ps3 = conectar.getCon().prepareStatement("SELECT id FROM usuario ORDER BY ID DESC LIMIT 1");
                    ResultSet rs = ps3.executeQuery();
                    if(rs != null){
                        while(rs.next()){
                            idUser = rs.getInt("id");
                        }
                    }
                    PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO clientes(nome,email,cpf,telefone,endereco,id_usuario) VALUES(?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
                    ps2.setString(1,cliente.getNome());
                    ps2.setString(2,cliente.getEmail());
                    ps2.setInt(3,cliente.getCpf());
                    ps2.setString(4,cliente.getTelefone());
                    ps2.setString(5,cliente.getEndereco());
                    ps2.setInt(6,idUser);
                    if(!ps2.execute()){ 
			resultado = true;
                    }
		}
	}catch(SQLException e){
		System.out.println(e.getMessage());
	}
        return resultado;
    }
    public boolean editCliente(int cpf, Cliente cliente){
                int cpf_oficial = cpf;
                try{
        		Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco.
			PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE clientes SET nome=?, email=?, endereco=?, telefone=? WHERE cpf=?");
			ps.setString(1,cliente.getNome());
                        ps.setString(2,cliente.getEmail());
                        ps.setString(3,cliente.getEndereco());
                        ps.setString(4,cliente.getTelefone());
                        ps.setInt(5,cpf_oficial);
			ps.execute();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
        return true;
    }
    public boolean deleteCliente(int cpf_oficial){
        try{
        		Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco.
                        int idUser = 0;
                            PreparedStatement ps3 = conectar.getCon().prepareStatement("SELECT * FROM clientes WHERE cpf=? LIMIT 1");
                            ps3.setInt(1,cpf_oficial);
                            ResultSet rs = ps3.executeQuery();
                            if(rs != null){
                                while(rs.next()){
                                    idUser = rs.getInt("id_usuario");
                                }
                            }
			PreparedStatement ps = conectar.getCon().prepareStatement("DELETE FROM animais WHERE cpfCliente=?");
                        ps.setInt(1,cpf_oficial);
			if(!ps.execute()){
                            PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM clientes WHERE cpf=?");
                            ps2.setInt(1,cpf_oficial);
                            if(!ps2.execute()){
                                PreparedStatement ps4 = conectar.getCon().prepareStatement("DELETE FROM usuario WHERE id=?");
                                ps4.setInt(1,idUser);
                                ps4.execute();
                            }
                        }
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
        return true;
    }
    // Fazer import da classe java.util.ArrayList
    public ArrayList consultarClientes(){
        ArrayList lista = new ArrayList<>(); // Cria uma lista de objetos de Cliente
        //lista = null; // Armazena valor nulo na lista.
        try{
        	Conexao conectar = new Conexao(); // Abre a conexão com o banco
                PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM clientes;"); // Definir o comando que será executado
                ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
            	if(rs != null){ // Verifica se o resultado é nulo
                   while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
                        Cliente li = new Cliente("","");
                        li.setCpf(rs.getInt("cpf"));  
                   	li.setNome(rs.getString("nome"));
                   	li.setEmail(rs.getString("email"));
                   	li.setTelefone(rs.getString("telefone"));
                   	li.setEndereco(rs.getString("endereco"));
                        lista.add(li);
                    }
                }else{
                    lista = null;
		}
	}catch(SQLException e){
            lista = null;
        }
            return lista;
    }
}