package Controle;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class ControlUser {
// Fazer import da classe java.util.ArrayList
public int consultarTipo(String loginU, String senhaU){
    int tipoUser = 0;
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM usuario WHERE login = ? && senha = ?;"); // Definir o comando que será executado
ps.setString(2,senhaU);
ps.setString(1,loginU);
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
    tipoUser = rs.getInt("tipoUsuario");
}
}
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return tipoUser;
}
}