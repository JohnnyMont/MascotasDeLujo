package Controle;
import Modelo.Secretaria;
import Modelo.Cliente;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
public class ControlSecretaria {
    public static void cadastrarCliente(){
        //cadastrar cliente
    }
    public static void alterarDadosClientes(){
        //alterar dados do cliente
    }
    public static void cadastrarAnimais(){
        //cadastrar animal
    }
    public static void fecharCompra(){
        //fechar compra
    }
    public static void visualizarClientes(){
        //visualizar clientes
    }
    public static void excluirClientes(){
        //excluir clientes
    }
    public static void consultarServicos(){
        //consultar serviços
    }
}