package Controle;
import Modelo.Cliente;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
import static java.lang.Integer.parseInt;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlAnimal {
    private Animais animal;
    public boolean cadAnimal(Animais animal){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO animais(nome,tipo,raca,tamanho,peso,idade,cpfCliente) VALUES(?,?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
ps2.setString(1,animal.getNome());
ps2.setString(2,animal.getTipo());
ps2.setString(3,animal.getRaca());
ps2.setString(4,animal.getTamanho());
ps2.setString(5,animal.getPeso());
ps2.setInt(6,animal.getIdade());
ps2.setInt(7,animal.getCpf_cliente());
if(!ps2.execute()){ 
    resultado = true;
}
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return resultado;
}
public boolean editAnimal(int id, Animais animal){
    int id_oficial = id;
    try{
Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco.
PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE animais SET nome=?, tipo=?, raca=?, tamanho=?,peso=?,idade=?,cpfCliente=? WHERE id=?");
ps.setString(1,animal.getNome());
ps.setString(2,animal.getTipo());
ps.setString(3,animal.getRaca());
ps.setString(4,animal.getTamanho());
ps.setString(5,animal.getPeso());
ps.setInt(6,animal.getIdade());
ps.setInt(7,animal.getCpf_cliente());
ps.setInt(8,id_oficial);
ps.execute();
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return true;
}
public boolean deleteAnimal(int id){
    try{
Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco
PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM animais WHERE id=?");
ps2.setInt(1,id);
ps2.execute();
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return true;
}
// Fazer import da classe java.util.ArrayList
public ArrayList consultarAnimais(){
ArrayList lista = new ArrayList<>(); // Cria uma lista de objetos de Cliente
//lista = null; // Armazena valor nulo na lista.
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM animais"); // Definir o comando que será executado
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
    Animais li = new Animais();
    li.setId(rs.getInt("id"));
    li.setNome(rs.getString("nome"));
    li.setTipo(rs.getString("tipo"));
    li.setTamanho(rs.getString("tamanho"));
    li.setRaca(rs.getString("raca"));
    li.setPeso(rs.getString("peso"));
    li.setIdade(rs.getInt("idade"));
    li.setCpf_cliente(rs.getInt("cpfCliente"));
    lista.add(li);
}
}else{
    lista = null;
}
}catch(SQLException e){
    lista = null;
    System.out.println(e.getMessage());
}
return lista;
}
}