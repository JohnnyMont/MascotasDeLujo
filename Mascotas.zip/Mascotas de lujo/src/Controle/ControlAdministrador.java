package Controle;
import Modelo.Admin;
import Modelo.Servicos;
import Modelo.Animais;
import Modelo.Compra;
public class ControlAdministrador {
    public static void gerarRelatorios(){
        //gerar Relatórios
    }
    public static void cadastrarServicos(){
        //cadastrar serviços
    }
    public static void consultarServicos(){
        //consultar serviços
    }
    public static void alterarDadosServicos(){
        //alterar Daddos dos serviços
    }
    public static void excluirServicos(){
        //excluir Serviços
    }
    public static void colocarServicoPromocao(){
        //colocar serviço em promoção
    }
}