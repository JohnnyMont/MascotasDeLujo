package Controle;
import Modelo.Admin;
import Modelo.Servicos;
import Modelo.Servicos;
import Modelo.Compra;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlAdministrador {
    public static void gerarRelatorios(){
        //gerar Relatórios
    }
    public boolean cadServico(Servicos servico){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO servicos(disponibilidade,indicacao,preco,desconto) VALUES(?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
ps2.setString(1,servico.getDisponibilidade());
ps2.setString(2,servico.getIndicacao());
ps2.setString(3,servico.getPreco());
ps2.setString(4,servico.getDesconto());
if(!ps2.execute()){ 
    resultado = true;
}
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return resultado;
}
public boolean editServico(int id, Servicos servico){
    int id_oficial = id;
    try{
Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco.
PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE servicos SET disponibilidade=?, indicacao=?, preco=?, desconto=? WHERE id=?");
ps.setString(1,servico.getDisponibilidade());
ps.setString(2,servico.getIndicacao());
ps.setString(3,servico.getPreco());
ps.setString(4,servico.getDesconto());
ps.setInt(5,id_oficial);
ps.execute();
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return true;
}
public boolean colocarPromocao(int id, int desconto){
    try{
Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco.
PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE servicos SET desconto=? WHERE id=?");
ps.setInt(1,desconto);
ps.setInt(2,id);
ps.execute();
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return true;
}
public boolean deleteServico(int id){
    try{
Conexao conectar = new Conexao(); // Executar conexÃ£o com o banco
PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM servicos WHERE id=?");
ps2.setInt(1,id);
ps2.execute();
}catch(SQLException e){
    System.out.println(e.getMessage());
}
return true;
}
// Fazer import da classe java.util.ArrayList
public ArrayList consultarServicos(){
ArrayList lista = new ArrayList<>(); // Cria uma lista de objetos de Cliente
//lista = null; // Armazena valor nulo na lista.
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos"); // Definir o comando que será executado
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
    Servicos li = new Servicos();
    li.setId(rs.getInt("id"));
    li.setIndicacao(rs.getString("indicacao"));
    li.setDesconto(rs.getString("desconto"));
    li.setDisponibilidade(rs.getString("disponibilidade"));
    li.setPreco(rs.getString("preco"));
    lista.add(li);
}
}else{
    lista = null;
}
}catch(SQLException e){
    lista = null;
    System.out.println(e.getMessage());
}
return lista;
}
public ArrayList consultarServicosId(int id){
ArrayList lista = new ArrayList<>(); // Cria uma lista de objetos de Cliente
//lista = null; // Armazena valor nulo na lista.
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE id = ?"); // Definir o comando que será executado
ps.setInt(1,id);
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
    Servicos li = new Servicos();
    li.setId(rs.getInt("id"));
    li.setIndicacao(rs.getString("indicacao"));
    li.setDesconto(rs.getString("desconto"));
    li.setDisponibilidade(rs.getString("disponibilidade"));
    li.setPreco(rs.getString("preco"));
    lista.add(li);
}
}else{
    lista = null;
}
}catch(SQLException e){
    lista = null;
    System.out.println(e.getMessage());
}
return lista;
}
public ArrayList consultarServicosIndicacao(String indicacao){
ArrayList lista = new ArrayList<>(); // Cria uma lista de objetos de Cliente
//lista = null; // Armazena valor nulo na lista.
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE indicacao = ?"); // Definir o comando que será executado
ps.setString(1,indicacao);
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
while(rs.next()){ // Enquanto existir tuplas na consulta... verifica se há uma tupla seguinte, senão a repetição para
    Servicos li = new Servicos();
    li.setId(rs.getInt("id"));
    li.setIndicacao(rs.getString("indicacao"));
    li.setDesconto(rs.getString("desconto"));
    li.setDisponibilidade(rs.getString("disponibilidade"));
    li.setPreco(rs.getString("preco"));
    lista.add(li);
}
}else{
    lista = null;
}
}catch(SQLException e){
    lista = null;
    System.out.println(e.getMessage());
}
return lista;
}
    public boolean confirmar(String senhaU){
try{
Conexao conectar = new Conexao(); // Abre a conexão com o banco
PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM administrador WHERE senhaExtra = ?;"); // Definir o comando que será executado
ps.setString(1,senhaU);
ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
if(rs != null){ // Verifica se o resultado é nulo
    while(rs.next()){
        return true;
    }
}
}catch(SQLException e){
    System.out.println(e.getMessage());
}
        return false;
    }
}
